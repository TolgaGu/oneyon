<footer class="footer">
  <div class="container-fluid">
    <nav class="float-left">
      <ul>
        <li>
          <a href="#">
            Monea
          </a>
        </li>
        <li>
          <a href="#">
            A propos
          </a>
        </li>
        <li>
          <a href="#">
            Mention légales
          </a>
        </li>
        <li>
          <a href="#">
            Abonnement
          </a>
        </li>
      </ul>
    </nav>
    <div class="copyright float-right">
      &copy;
      <script>
        document.write(new Date().getFullYear())
      </script>, Copyright <i class="material-icons">insert_chart_outlined</i> by
      <a href="https://www.monea.fr/" target="_blank">Monea</a>
    </div>
  </div>
</footer>
