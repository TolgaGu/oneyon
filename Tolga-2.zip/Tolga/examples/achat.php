<!DOCTYPE html>
<html lang="fr">

<?php include('header.php'); ?>
<body class="">
  <div class="wrapper ">
    <?php include('navbar.php'); ?>


    <div class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-6">
            <div class="card ">
              <div class="card-body text-center">
                <h5 class="card-text">Ajouter une dépense</h5>
                <button class="btn btn-success btn-fill" onclick="openForm()">Nouvelle dépense</button>
                <div class="form-popup" id="myForm">

              <div class="card-body ">
                <div class="form-group">
                    <div class="card-body ">
                      <form method="get" action="/" class="form-horizontal">
                        <div class="container">
                          <div class="row">
                            <div class="col-12">
                              <label class="col-form-label text-align-left">Date dépense </label>
                              <div class="">
                                <div class="form-group">
                                  <input type="text" class="form-control datepicker" value="01/05/2020 ">
                                </div>
                              </div>
                            </div>
                            <div class="col-12">
                              <div class="">
                                <div class="form-group">
                                  <input type="text" class="form-control" placeholder="N° Facture">
                                </div>
                              </div>
                            </div>
                          </div>
                          <div class="row">
                            <div class="col-12">
                              <div class="">
                                <div class="form-group">
                                  <input type="text" class="form-control" placeholder="Fournisseur / Prestataire">
                                </div>
                              </div>
                            </div>
                            <div class="col-md-6">
                              <div class="">
                                <select class="selectpicker" data-size="10" data-style="select-with-transition" title="Single Select">
                                  <option disabled selected>Catégorie ...</option>
                                  <option value="1"> Achats liés à l'activité</option>
                                  <option value="2"> Loyers et charges locatives</option>
                                  <option value="3"> Télécom et internet </option>
                                  <option value="4"> Frais postaux </option>
                                  <option value="5"> Banques et assurances </option>
                                  <option value="6"> Frais administratifs et amendes </option>
                                  <option value="7"> Prestations de services diverses et honoraires </option>
                                  <option value="8"> Sous-traitance </option>
                                  <option value="9"> Eau, gaz, électricité </option>
                                  <option value="10"> Nettoyage, réparation et maintenance </option>
                                  <option value="11"> Locations diverses </option>
                                  <option value="12"> Frais de déplacements </option>
                                  <option value="13"> Repas et restaurants</option>
                                  <option value="14"> Cadeaux clients </option>
                                  <option value="15"> Cotisations sociales et impôts </option>
                                  <option value="16"> Rémunération de l’auto-entrepreneur </option>
                                  <option value="17"> Salaires du personnel </option>
                                  <option value="18"> Formations </option>
                                  <option value="19"> TVA </option>
                                  <option value="20"> Remboursements de crédits et crédits baux </option>
                                  <option value="21"> Autres dépenses non liées à l'activité </option>
                                  <option value="22"> Publicité / Marketing </option>
                                </select>
                              </div>
                            </div>
                          </div>
                          <div class="row">
                            <div class="col-12">
                              <div class="">
                                <div class="form-group">
                                  <input type="number" class="form-control" placeholder="Montant">
                                </div>
                              </div>
                            </div>
                            <div class="col-md-6">
                              <div class="">
                                <select class="selectpicker" data-size="7" data-style="select-with-transition" title="Single Select">
                                  <option disabled selected>Mode de règlement</option>
                                  <option value="2">Carte bancaire</option>
                                  <option value="3">Chèque</option>
                                  <option value="4">Espèce</option>
                                </select>
                              </div>
                            </div>
                            <div class="col-12">
                              <div class="">
                                <div class="form-group">
                                  <input type="text" class="form-control" placeholder="Commentaire">
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div class="card-footer ">
                          <button type="submit" class="btn btn-fill btn-success">Ajouter</button>
                          <button type="button" class="btn btn-fill btn-danger" onclick="closeForm()">Annuler</button>
                        </div>
                      </form>
                    </div>
                </div>
              </div>
            </div>
          </div>
            </div>
          </div>
          <div class="col-md-12">
            <div class="card">
              <div class="card-header card-header-success card-header-icon">
                <div class="card-icon">
                  <i class="material-icons">file_copy</i>
                </div>
                <h4 class="card-title">Liste des dépenses</h4>
              </div>
              <div class="card-body">
                <div class="material-datatables">
                  <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
                    <thead>
                      <tr>
                        <th>Date</th>
                        <th>Fournisseur / Prestataire</th>
                        <th>Catégorie</th>
                        <th>Montant</th>
                        <th class="disabled-sorting text-right">Actions</th>
                      </tr>
                    </thead>
                    <tfoot>
                      <tr>
                        <th>Date</th>
                        <th>Fournisseur / Prestataire</th>
                        <th>Catégorie</th>
                        <th>Montant</th>
                        <th class="text-right">Actions</th>
                      </tr>
                    </tfoot>
                    <tbody>
                      <tr>
                        <td>28/03/2020</td>
                        <td>Orange</td>
                        <td>Télécommunication</td>
                        <td>&euro; 49</td>
                        <td class="td-actions text-right">
                          <button type="button" rel="tooltip" class="btn btn-danger">
                            <i class="material-icons">close</i>
                          </button>
                          <button type="button" rel="tooltip" class="btn btn-success">
                            <i class="material-icons">visibility</i>
                          </button>
                        </td>
                      </tr>
                      <tr>
                        <td>18/03/2020</td>
                        <td>Total</td>
                        <td>Carburant</td>
                        <td>&euro; 79</td>
                        <td class="td-actions text-right">
                          <button type="button" rel="tooltip" class="btn btn-danger">
                            <i class="material-icons">close</i>
                          </button>
                          <button type="button" rel="tooltip" class="btn btn-success">
                            <i class="material-icons">visibility</i>
                          </button>
                        </td>
                      </tr>
                      <tr>
                        <td>28/03/2020</td>
                        <td>Propriétaire</td>
                        <td>Loyer</td>
                        <td>&euro; 849</td>
                        <td class="td-actions text-right">
                          <button type="button" rel="tooltip" class="btn btn-danger">
                            <i class="material-icons">close</i>
                          </button>
                          <button type="button" rel="tooltip" class="btn btn-success">
                            <i class="material-icons">visibility</i>
                          </button>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
              <!-- end content-->
            </div>
            <!--  end card  -->
          </div>
        </div>
      </div>
    </div>


          <?php include('footer.php'); ?>
        </div>
      </div>
      <?php include('widget-sidebar.php'); ?>
      <!--   Core JS Files   -->
      <script src="../../assets/js/core/jquery.min.js"></script>
      <script src="../../assets/js/core/popper.min.js"></script>
      <script src="../../assets/js/core/bootstrap-material-design.min.js"></script>
      <script src="../../assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
      <!-- Plugin for the momentJs  -->
      <script src="../../assets/js/plugins/moment.min.js"></script>
      <!--  Plugin for Sweet Alert -->
      <script src="../../assets/js/plugins/sweetalert2.js"></script>
      <!-- Forms Validations Plugin -->
      <script src="../../assets/js/plugins/jquery.validate.min.js"></script>
      <!-- Plugin for the Wizard, full documentation here: https://github.com/VinceG/twitter-bootstrap-wizard -->
      <script src="../../assets/js/plugins/jquery.bootstrap-wizard.js"></script>
      <!--	Plugin for Select, full documentation here: http://silviomoreto.github.io/bootstrap-select -->
      <script src="../../assets/js/plugins/bootstrap-selectpicker.js"></script>
      <!--  Plugin for the DateTimePicker, full documentation here: https://eonasdan.github.io/bootstrap-datetimepicker/ -->
      <script src="../../assets/js/plugins/bootstrap-datetimepicker.min.js"></script>
      <!--  DataTables.net Plugin, full documentation here: https://datatables.net/  -->
      <script src="../../assets/js/plugins/jquery.dataTables.min.js"></script>
      <!--	Plugin for Tags, full documentation here: https://github.com/bootstrap-tagsinput/bootstrap-tagsinputs  -->
      <script src="../../assets/js/plugins/bootstrap-tagsinput.js"></script>
      <!-- Plugin for Fileupload, full documentation here: http://www.jasny.net/bootstrap/javascript/#fileinput -->
      <script src="../../assets/js/plugins/jasny-bootstrap.min.js"></script>
      <!--  Full Calendar Plugin, full documentation here: https://github.com/fullcalendar/fullcalendar    -->
      <script src="../../assets/js/plugins/fullcalendar.min.js"></script>
      <!-- Vector Map plugin, full documentation here: http://jvectormap.com/documentation/ -->
      <script src="../../assets/js/plugins/jquery-jvectormap.js"></script>
      <!--  Plugin for the Sliders, full documentation here: http://refreshless.com/nouislider/ -->
      <script src="../../assets/js/plugins/nouislider.min.js"></script>
      <!-- Include a polyfill for ES6 Promises (optional) for IE11, UC Browser and Android browser support SweetAlert -->
      <script src="https://cdnjs.cloudflare.com/ajax/libs/core-js/2.4.1/core.js"></script>
      <!-- Library for adding dinamically elements -->
      <script src="../../assets/js/plugins/arrive.min.js"></script>
      <!--  Google Maps Plugin    -->
      <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
      <!-- Chartist JS -->
      <script src="../../assets/js/plugins/chartist.min.js"></script>
      <!--  Notifications Plugin    -->
      <script src="../../assets/js/plugins/bootstrap-notify.js"></script>
      <!-- Control Center for Material Dashboard: parallax effects, scripts for the example pages etc -->
      <script src="../../assets/js/material-dashboard.js?v=2.1.2" type="text/javascript"></script>
      <!-- Material Dashboard DEMO methods, don't include it in your project! -->
      <script src="../../assets/demo/demo.js"></script>
      <script>
        $(document).ready(function() {
          $().ready(function() {
            $sidebar = $('.sidebar');

            $sidebar_img_container = $sidebar.find('.sidebar-background');

            $full_page = $('.full-page');

            $sidebar_responsive = $('body > .navbar-collapse');

            window_width = $(window).width();

            fixed_plugin_open = $('.sidebar .sidebar-wrapper .nav li.active a p').html();

            if (window_width > 767 && fixed_plugin_open == 'Dashboard') {
              if ($('.fixed-plugin .dropdown').hasClass('show-dropdown')) {
                $('.fixed-plugin .dropdown').addClass('open');
              }

            }

            $('.fixed-plugin a').click(function(event) {
              // Alex if we click on switch, stop propagation of the event, so the dropdown will not be hide, otherwise we set the  section active
              if ($(this).hasClass('switch-trigger')) {
                if (event.stopPropagation) {
                  event.stopPropagation();
                } else if (window.event) {
                  window.event.cancelBubble = true;
                }
              }
            });

            $('.fixed-plugin .active-color span').click(function() {
              $full_page_background = $('.full-page-background');

              $(this).siblings().removeClass('active');
              $(this).addClass('active');

              var new_color = $(this).data('color');

              if ($sidebar.length != 0) {
                $sidebar.attr('data-color', new_color);
              }

              if ($full_page.length != 0) {
                $full_page.attr('filter-color', new_color);
              }

              if ($sidebar_responsive.length != 0) {
                $sidebar_responsive.attr('data-color', new_color);
              }
            });

            $('.fixed-plugin .background-color .badge').click(function() {
              $(this).siblings().removeClass('active');
              $(this).addClass('active');

              var new_color = $(this).data('background-color');

              if ($sidebar.length != 0) {
                $sidebar.attr('data-background-color', new_color);
              }
            });

            $('.fixed-plugin .img-holder').click(function() {
              $full_page_background = $('.full-page-background');

              $(this).parent('li').siblings().removeClass('active');
              $(this).parent('li').addClass('active');


              var new_image = $(this).find("img").attr('src');

              if ($sidebar_img_container.length != 0 && $('.switch-sidebar-image input:checked').length != 0) {
                $sidebar_img_container.fadeOut('fast', function() {
                  $sidebar_img_container.css('background-image', 'url("' + new_image + '")');
                  $sidebar_img_container.fadeIn('fast');
                });
              }

              if ($full_page_background.length != 0 && $('.switch-sidebar-image input:checked').length != 0) {
                var new_image_full_page = $('.fixed-plugin li.active .img-holder').find('img').data('src');

                $full_page_background.fadeOut('fast', function() {
                  $full_page_background.css('background-image', 'url("' + new_image_full_page + '")');
                  $full_page_background.fadeIn('fast');
                });
              }

              if ($('.switch-sidebar-image input:checked').length == 0) {
                var new_image = $('.fixed-plugin li.active .img-holder').find("img").attr('src');
                var new_image_full_page = $('.fixed-plugin li.active .img-holder').find('img').data('src');

                $sidebar_img_container.css('background-image', 'url("' + new_image + '")');
                $full_page_background.css('background-image', 'url("' + new_image_full_page + '")');
              }

              if ($sidebar_responsive.length != 0) {
                $sidebar_responsive.css('background-image', 'url("' + new_image + '")');
              }
            });

            $('.switch-sidebar-image input').change(function() {
              $full_page_background = $('.full-page-background');

              $input = $(this);

              if ($input.is(':checked')) {
                if ($sidebar_img_container.length != 0) {
                  $sidebar_img_container.fadeIn('fast');
                  $sidebar.attr('data-image', '#');
                }

                if ($full_page_background.length != 0) {
                  $full_page_background.fadeIn('fast');
                  $full_page.attr('data-image', '#');
                }

                background_image = true;
              } else {
                if ($sidebar_img_container.length != 0) {
                  $sidebar.removeAttr('data-image');
                  $sidebar_img_container.fadeOut('fast');
                }

                if ($full_page_background.length != 0) {
                  $full_page.removeAttr('data-image', '#');
                  $full_page_background.fadeOut('fast');
                }

                background_image = false;
              }
            });

            $('.switch-sidebar-mini input').change(function() {
              $body = $('body');

              $input = $(this);

              if (md.misc.sidebar_mini_active == true) {
                $('body').removeClass('sidebar-mini');
                md.misc.sidebar_mini_active = false;

                $('.sidebar .sidebar-wrapper, .main-panel').perfectScrollbar();

              } else {

                $('.sidebar .sidebar-wrapper, .main-panel').perfectScrollbar('destroy');

                setTimeout(function() {
                  $('body').addClass('sidebar-mini');

                  md.misc.sidebar_mini_active = true;
                }, 300);
              }

              // we simulate the window Resize so the charts will get updated in realtime.
              var simulateWindowResize = setInterval(function() {
                window.dispatchEvent(new Event('resize'));
              }, 180);

              // we stop the simulation of Window Resize after the animations are completed
              setTimeout(function() {
                clearInterval(simulateWindowResize);
              }, 1000);

            });
          });
        });
      </script>
      <script>
        $(document).ready(function() {
          $('#datatables').DataTable({
            "pagingType": "full_numbers",
            "lengthMenu": [
              [10, 25, 50, -1],
              [10, 25, 50, "All"]
            ],
            responsive: true,
            language: {
              search: "_INPUT_",
              searchPlaceholder: "Rechercher client",
            }
          });

          var table = $('#datatable').DataTable();

          // Edit record
          table.on('click', '.edit', function() {
            $tr = $(this).closest('tr');
            var data = table.row($tr).data();
            alert('You press on Row: ' + data[0] + ' ' + data[1] + ' ' + data[2] + '\'s row.');
          });

          // Delete a record
          table.on('click', '.remove', function(e) {
            $tr = $(this).closest('tr');
            table.row($tr).remove().draw();
            e.preventDefault();
          });

          //Like record
          table.on('click', '.like', function() {
            alert('You clicked on Like button');
          });
        });

        /*Pour ouvrir le formulaire*/
        function openForm() {
          document.getElementById("myForm").style.display = "block";
        }

        function closeForm() {
          document.getElementById("myForm").style.display = "none";
        }
        /*FIN Pour ouvrir le formulaire*/
      </script>
    </body>

    </html>
