<div class="sidebar" data-color="rose" data-background-color="black" data-image="../assets/img/sidebar-1.jpg">
  <!--
    Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

    Tip 2: you can also add an image using data-image tag
-->

  <div class="sidebar-wrapper">
    <div class="user">
      <div class="photo">
        <img src="../assets/img/faces/avatar.jpg" />
      </div>
      <div class="user-info">
        <a data-toggle="collapse" href="dashboard.php" class="username">
          <span>
            NET'CAR Detailing

          </span>
        </a>
        <!--<div class="collapse" id="collapseExample">
          <ul class="nav">
            <li class="nav-item">
              <a class="nav-link" href="parametre.php">
                <span class="sidebar-mini"> MP </span>
                <span class="sidebar-normal"> Mes paramètres </span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="entreprise.php">
                <span class="sidebar-mini"> ME </span>
                <span class="sidebar-normal"> Mon entreprise </span>
              </a>
            </li>
          </ul>
        </div>-->
      </div>
    </div>
    <ul class="nav">
      <li class="nav-item active ">
        <a class="nav-link" href="../examples/dashboard.php">
          <i class="material-icons">dashboard</i>
          <p> Mon tableau de bord </p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="client.php">
          <i class="material-icons">account_box</i>
          <p> Mes clients </p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="article.php">
          <i class="material-icons">add_shopping_cart</i>
          <p> Mes articles </p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="facture.php">
          <i class="material-icons">euro</i>
          <p> Mes devis/factures </p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" data-toggle="collapse" href="#formsExamples">
          <i class="material-icons">content_paste</i>
          <p> Ma Comptabilité
            <b class="caret"></b>
          </p>
        </a>
        <div class="collapse" id="formsExamples">
          <ul class="nav">
            <li class="nav-item ">
              <a class="nav-link" href="../examples/declaration.php">
                <span class="sidebar-mini"> MD </span>
                <span class="sidebar-normal"> Mes déclarations </span>
              </a>
            </li>
            <!--<li class="nav-item ">
              <a class="nav-link" href="../examples/forms/extended.html">
                <span class="sidebar-mini"> LR </span>
                <span class="sidebar-normal"> Mes recettes </span>
              </a>
            </li>-->
            <li class="nav-item ">
              <a class="nav-link" href="../examples/achat.php">
                <span class="sidebar-mini"> MA </span>
                <span class="sidebar-normal"> Mes achats </span>
              </a>
            </li>
          </ul>
        </div>
      </li>
      <hr>
      <li class="nav-item ">
        <a class="nav-link" href="entreprise.php">
          <i class="material-icons">store</i>
          <p> Mon entreprise </p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="parametre.php">
          <i class="material-icons">settings</i>
          <p> Mes paramètres </p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="parametre.php">
          <i class="material-icons">exit_to_app</i>
          <p> Déconnexion </p>
        </a>
      </li>
    </ul>
  </div>
</div>
<div class="main-panel">
  <!-- Navbar -->
  <nav class="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top ">
    <div class="container-fluid">
      <div class="navbar-wrapper">
        <div class="navbar-minimize">
          <button id="minimizeSidebar" class="btn btn-just-icon btn-white btn-fab btn-round">
            <i class="material-icons text_align-center visible-on-sidebar-regular">more_vert</i>
            <i class="material-icons design_bullet-list-67 visible-on-sidebar-mini">view_list</i>
          </button>
        </div>
        <a class="navbar-brand" href="dashboard.php">Mon tableau de bord</a>
      </div>
      <button class="navbar-toggler" type="button" data-toggle="collapse" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
        <span class="sr-only">Toggle navigation</span>
        <span class="navbar-toggler-icon icon-bar"></span>
        <span class="navbar-toggler-icon icon-bar"></span>
        <span class="navbar-toggler-icon icon-bar"></span>
      </button>
      <div class="collapse navbar-collapse justify-content-end">
        <form class="navbar-form">
          <div class="input-group no-border">
            <input type="text" value="" class="form-control" placeholder="Rechercher...">
            <button type="submit" class="btn btn-white btn-round btn-just-icon">
              <i class="material-icons">search</i>
              <div class="ripple-container"></div>
            </button>
          </div>
        </form>
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link" href="dashboard.php">
              <i class="material-icons">dashboard</i>
              <p class="d-lg-none d-md-block">
                Tableau de bord
              </p>
            </a>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link" href="http://example.com" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <i class="material-icons">notifications</i>
              <span class="notification">5</span>
              <p class="d-lg-none d-md-block">
                Notification(s)
              </p>
            </a>
            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
              <a class="dropdown-item" href="#">Mike John responded to your email</a>
              <a class="dropdown-item" href="#">You have 5 new tasks</a>
              <a class="dropdown-item" href="#">You're now friend with Andrew</a>
              <a class="dropdown-item" href="#">Another Notification</a>
              <a class="dropdown-item" href="#">Another One</a>
            </div>
          </li>
          <!--<li class="nav-item dropdown">
            <a class="nav-link" href="javascript:;" id="navbarDropdownProfile" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <i class="material-icons">person</i>
              <p class="d-lg-none d-md-block">
                Profil
              </p>
            </a>
            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownProfile">
              <a class="dropdown-item" href="profil.php">Profile</a>
              <a class="dropdown-item" href="#">Settings</a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="#">Log out</a>
            </div>
          </li>-->
        </ul>
      </div>
    </div>
  </nav>
  <!-- End Navbar -->
