<!DOCTYPE html>
<html lang="fr">

<?php include('header.php'); ?>
<body class="">
  <div class="wrapper ">
    <?php include('navbar.php'); ?>
          <div class="content">
            <div class="container-fluid">
              <div class="row">
                <div class="col-md-12 ml-auto mr-auto">
                  <div class="page-categories">
                    <ul class="nav nav-pills nav-pills-warning nav-pills-icons justify-content-center" role="tablist">
                      <li class="nav-item">
                        <a class="nav-link active" data-toggle="tab" href="#profil" role="tablist">
                          <i class="material-icons">account_circle</i> Mon profil
                        </a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" data-toggle="tab" href="#connexion" role="tablist">
                          <i class="material-icons">vpn_key</i> Connexion
                        </a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" data-toggle="tab" href="#abonnement" role="tablist">
                          <i class="material-icons">speed</i> Mon abonnement
                        </a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" data-toggle="tab" href="#facture" role="tablist">
                          <i class="material-icons">file_copy</i> Mes factures
                        </a>
                      </li>
                    </ul>
                    <div class="tab-content tab-space tab-subcategories">
<!-- ONGLET PROFIL-->
                      <div class="tab-pane active" id="profil">
                        <div class="col-md-12">
                          <div class="card ">
                            <div class="card-header card-header-warning card-header-icon">
                              <div class="card-icon">
                                <i class="material-icons">account_circle</i>
                              </div>
                            </div>
                            <div class="card-body ">
                              <form method="get" action="/" class="form-horizontal">
                                <h3>Mon profil</h3>
                                <div class="row">
                                  <label class="col-sm-2 col-form-label">Nom</label>
                                  <div class="col-sm-10">
                                    <div class="form-group">
                                      <input type="text" class="form-control" placeholder="Gurel">
                                    </div>
                                  </div>
                                  <label class="col-sm-2 col-form-label">Prénom</label>
                                  <div class="col-sm-10">
                                    <div class="form-group">
                                      <input type="text" class="form-control" placeholder="Huseyin">
                                    </div>
                                  </div>
                                  <label class="col-sm-2 col-form-label">Email</label>
                                  <div class="col-sm-10">
                                    <div class="form-group">
                                      <input type="text" class="form-control" placeholder="husgur54@gmail.com" email="true">
                                    </div>
                                  </div>
                                </div>
                                <h3>Coordonnées et adresse</h3>
                                <div class="row">
                                  <label class="col-sm-2 col-form-label">Adresse</label>
                                  <div class="col-sm-10">
                                    <div class="form-group">
                                      <input type="text" class="form-control" placeholder="Adresse">
                                    </div>
                                  </div>
                                </div>
                                <div class="row">
                                  <label class="col-sm-2 col-form-label">CP</label>
                                  <div class="col-sm-10">
                                    <div class="form-group">
                                      <input type="text" class="form-control" placeholder="67850">
                                    </div>
                                  </div>
                                </div>
                                <div class="row">
                                  <label class="col-sm-2 col-form-label">Ville</label>
                                  <div class="col-sm-10">
                                    <div class="form-group">
                                      <input type="text" class="form-control" placeholder="Herrlisheim">
                                    </div>
                                  </div>
                                </div>
                                <div class="row">
                                  <label class="col-sm-2 col-form-label">Téléphone</label>
                                  <div class="col-sm-10">
                                    <div class="form-group">
                                      <input type="text" class="form-control" placeholder="0638413477">
                                    </div>
                                  </div>
                                </div>
                                <div class="card-footer ">
                                  <button type="submit" class="btn btn-fill btn-success">Mettre à jour</button>
                                </div>
                              </form>
                            </div>
                          </div>
                        </div>
                      </div>
<!-- ONGLET CONNEXION-->
                    <div class="tab-pane" id="connexion">
                      <div class="container">
                        <div class="col-md-12">
                          <div class="card ">
                            <div class="card-header card-header-warning card-header-icon">
                              <div class="card-icon">
                                <i class="material-icons">vpn_key</i>
                              </div>
                            </div>
                            <div class="card-body ">
                              <form method="get" action="/" class="form-horizontal">
                                <h3>Modifier mon mot de passe</h3>
                                <div class="row">
                                  <label class="col-sm-2 col-form-label">Ancien mot de passe</label>
                                  <div class="col-sm-10">
                                    <div class="form-group">
                                      <input type="password" class="form-control">
                                    </div>
                                  </div>
                                </div>
                                <div class="row">
                                  <label class="col-sm-2 col-form-label">Nouveau mot de passe</label>
                                  <div class="col-sm-10">
                                    <div class="form-group">
                                      <input type="password" class="form-control">
                                    </div>
                                  </div>
                                </div>
                                <div class="row">
                                  <label class="col-sm-2 col-form-label" placeholder="Nouveau mot de passe">Confirmer nouveau mot de passe</label>
                                  <div class="col-sm-10">
                                    <div class="form-group">
                                      <input type="password" class="form-control">
                                    </div>
                                  </div>
                                </div>
                                <div class="card-footer ">
                                  <button type="submit" class="btn btn-fill btn-success">Mettre à jour</button>
                                </div>
                              </form>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
<!-- ONGLET ABONNEMENT -->

                      <div class="tab-pane" id="abonnement">
                        <div class="card">
                          <div class="card-header card-header-warning card-header-icon">
                            <div class="card-icon">
                              <i class="material-icons">speed</i>
                            </div>
                          </div>
                          <div class="container">
                            <h3>Mon abonnement</h3>
                            <div class="row">
                              <div class="col-lg-4 col-md-6">
                                <div class="card card-pricing">
                                  <h6 class="card-category"> Gratuit</h6>
                                  <div class="card-body">
                                    <!--<div class="card-icon icon-green ">
                                      <i class="material-icons">weekend</i>
                                    </div>-->
                                    <h3 class="card-title">Monea<br /><strong>GRATUIT</strong></h3>
                                    <p class="card-description">Testez <strong>gratuitement</strong> notre outil</p>
                                      <div class="card card-description">
                                        <table class="pad-td">
                                          <tr>
                                            <td class="text-align-left">Tableau de bord</td>
                                            <td><i class="material-icons icon-success">done</i></td>
                                          </tr>
                                          <tr>
                                            <td class="text-align-left">Creation client (max.10)</td>
                                            <td><i class="material-icons icon-success">done</i></td>
                                          </tr>
                                          <tr>
                                            <td class="text-align-left">Création devis/facture (max.10/mois)</td>
                                            <td><i class="material-icons icon-success">done</i></td>
                                          </tr>
                                          <tr>
                                            <td class="text-align-left">Livre de recette/depense</td>
                                            <td><i class="material-icons icon-success">done</i></td>
                                          </tr>
                                          <tr>
                                            <td class="text-align-left">Gestion de stock</td>
                                            <td><i class="material-icons icon-red">clear</i></td>
                                          </tr>
                                          <tr>
                                            <td class="text-align-left">Agenda</td>
                                            <td><i class="material-icons icon-red">clear</i></td>
                                          </tr>
                                        </table>
                                    </div>
                                  </div>
                                  <div class="card-footer justify-content-center ">
                                    <a href="#pablo" class="btn btn-round btn-white">Choisir</a>
                                  </div>
                                </div>
                              </div>
                              <div class="col-lg-4 col-md-6">
                                <div class="card card-pricing ">
                                  <h6 class="card-category"> Monea Start</h6>
                                  <div class="card-body">
                                    <!--<div class="card-icon icon-rose ">
                                      <i class="material-icons">flight_takeoff</i>
                                    </div>-->
                                    <h3 class="card-title">Monea <strong>Start</strong><br /><span class="font-price-abonnement">19€</span> / mois</h3>
                                    <p class="card-description">Découvrez notre offre démarrage</p>
                                    <div class="card card-description">
                                      <table class="pad-td">
                                        <tr>
                                          <td class="text-align-left">Tableau de bord</td>
                                          <td><i class="material-icons icon-success">done</i></td>
                                        </tr>
                                        <tr>
                                          <td class="text-align-left">Creation client</td>
                                          <td><i class="material-icons icon-success">done</i></td>
                                        </tr>
                                        <tr>
                                          <td class="text-align-left">Création devis/facture</td>
                                          <td><i class="material-icons icon-success">done</i></td>
                                        </tr>
                                        <tr>
                                          <td class="text-align-left">Livre de recette/depense</td>
                                          <td><i class="material-icons icon-success">done</i></td>
                                        </tr>
                                        <tr>
                                          <td class="text-align-left">Gestion de stock</td>
                                          <td><i class="material-icons icon-success">done</i></td>
                                        </tr>
                                        <tr>
                                          <td class="text-align-left">Agenda</td>
                                          <td><i class="material-icons icon-red">clear</i></td>
                                        </tr>
                                      </table>
                                      </div>
                                  </div>
                                  <div class="card-footer justify-content-center ">
                                    <a href="#pablo" class="btn btn-round btn-rose">Choisir</a>
                                  </div>
                                </div>
                              </div>
                              <div class="col-lg-4 col-md-6">
                                <div class="card card-pricing">
                                  <h6 class="card-category"> Monea Pro</h6>
                                  <div class="card-body">
                                    <!--<div class="card-icon icon-green ">
                                      <i class="material-icons">business_center</i>
                                    </div>-->
                                    <h3 class="card-title">Monea <strong>Pro</strong><br /><span class="font-price-abonnement">29€</span> / mois</h3>
                                    <p class="card-description">Découvrez notre offre Business</p>
                                    <div class="card card-description">
                                        <table class="pad-td">
                                          <tr>
                                            <td class="text-align-left">Tableau de bord</td>
                                            <td><i class="material-icons icon-success">done</i></td>
                                          </tr>
                                          <tr>
                                            <td class="text-align-left">Creation client</td>
                                            <td><i class="material-icons icon-success">done</i></td>
                                          </tr>
                                          <tr>
                                            <td class="text-align-left">Création devis/facture</td>
                                            <td><i class="material-icons icon-success">done</i></td>
                                          </tr>
                                          <tr>
                                            <td class="text-align-left">Livre de recette/depense</td>
                                            <td><i class="material-icons icon-success">done</i></td>
                                          </tr>
                                          <tr>
                                            <td class="text-align-left">Gestion de stock</td>
                                            <td><i class="material-icons icon-success">done</i></td>
                                          </tr>
                                          <tr>
                                            <td class="text-align-left">Agenda</td>
                                            <td><i class="material-icons icon-success">done</i></td>
                                          </tr>
                                        </table>
                                      </div>
                                  </div>
                                  <div class="card-footer justify-content-center ">
                                    <a href="#pablo" class="btn btn-round btn-rose">Choisir</a>
                                  </div>
                                </div>
                              </div>
                              <!--<div class="col-lg-3 col-md-6">
                                <div class="card card-pricing card-plain">
                                  <h6 class="card-category"> Extra Pack</h6>
                                  <div class="card-body">
                                    <div class="card-icon icon-green ">
                                      <i class="material-icons">account_balance</i>
                                    </div>
                                    <h3 class="card-title">159$</h3>
                                    <p class="card-description">This is good if your company size is 99+ Persons.</p>
                                  </div>
                                  <div class="card-footer justify-content-center ">
                                    <a href="#pablo" class="btn btn-round btn-white">Choose Plan</a>
                                  </div>
                                </div>
                              </div>-->
                            </div>
                          </div>
                        </div>
                      </div>
<!-- ONGLET FACTURE-->
                      <div class="tab-pane" id="facture">
                        <div class="card">
                          <div class="card-header card-header-warning card-header-icon">
                            <div class="card-icon">
                              <i class="material-icons">file_copy</i>
                            </div>
                            <h4 class="card-title">Mes factures</h4>
                          </div>
                          <div class="card-body">
                            <div class="table-responsive">
                              <table class="table">
                                <thead>
                                  <tr>
                                    <th class="text-center">#</th>
                                    <th>Date</th>
                                    <th>Libellé</th>
                                    <th>Status</th>
                                    <th>Montant</th>
                                    <th>Actions</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  <tr>
                                    <td class="text-center">1</td>
                                    <td>05/01/2020</td>
                                    <td>Monea Start</td>
                                    <td>Payé</td>
                                    <td>&euro; 19</td>
                                    <td class="td-actions text-right">
                                      <div class="padding-download">
                                          <button type="button" rel="tooltip" class="btn btn-info">
                                            <i class="material-icons">cloud_download</i>
                                          </button>
                                      </div>
                                      <button type="button" rel="tooltip" class="btn btn-success">
                                        <i class="material-icons">visibility</i>
                                      </button>
                                    </td>
                                  </tr>
                                  <tr>
                                    <td class="text-center">1</td>
                                    <td>05/03/2020</td>
                                    <td>Monea Pro</td>
                                    <td>Payé</td>
                                    <td>&euro; 29</td>
                                    <td class="td-actions text-right">
                                      <div class="padding-download">
                                          <button type="button" rel="tooltip" class="btn btn-info">
                                            <i class="material-icons">cloud_download</i>
                                          </button>
                                      </div>
                                      <button type="button" rel="tooltip" class="btn btn-success">
                                        <i class="material-icons">visibility</i>
                                      </button>
                                    </td>
                                  </tr>
                                  <tr>
                                    <td class="text-center">1</td>
                                    <td>05/03/2020</td>
                                    <td>Monea Pro</td>
                                    <td>Payé</td>
                                    <td>&euro; 29</td>
                                    <td class="td-actions text-right">
                                      <div class="padding-download">
                                          <button type="button" rel="tooltip" class="btn btn-info">
                                            <i class="material-icons">cloud_download</i>
                                          </button>
                                      </div>
                                      <button type="button" rel="tooltip" class="btn btn-success">
                                        <i class="material-icons">visibility</i>
                                      </button>
                                    </td>
                                  </tr>
                                </tbody>
                              </table>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <?php include('footer.php'); ?>
        </div>
      </div>
      <?php include('widget-sidebar.php'); ?>
      <!--   Core JS Files   -->
      <script src="../../assets/js/core/jquery.min.js"></script>
      <script src="../../assets/js/core/popper.min.js"></script>
      <script src="../../assets/js/core/bootstrap-material-design.min.js"></script>
      <script src="../../assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
      <!-- Plugin for the momentJs  -->
      <script src="../../assets/js/plugins/moment.min.js"></script>
      <!--  Plugin for Sweet Alert -->
      <script src="../../assets/js/plugins/sweetalert2.js"></script>
      <!-- Forms Validations Plugin -->
      <script src="../../assets/js/plugins/jquery.validate.min.js"></script>
      <!-- Plugin for the Wizard, full documentation here: https://github.com/VinceG/twitter-bootstrap-wizard -->
      <script src="../../assets/js/plugins/jquery.bootstrap-wizard.js"></script>
      <!--	Plugin for Select, full documentation here: http://silviomoreto.github.io/bootstrap-select -->
      <script src="../../assets/js/plugins/bootstrap-selectpicker.js"></script>
      <!--  Plugin for the DateTimePicker, full documentation here: https://eonasdan.github.io/bootstrap-datetimepicker/ -->
      <script src="../../assets/js/plugins/bootstrap-datetimepicker.min.js"></script>
      <!--  DataTables.net Plugin, full documentation here: https://datatables.net/  -->
      <script src="../../assets/js/plugins/jquery.dataTables.min.js"></script>
      <!--	Plugin for Tags, full documentation here: https://github.com/bootstrap-tagsinput/bootstrap-tagsinputs  -->
      <script src="../../assets/js/plugins/bootstrap-tagsinput.js"></script>
      <!-- Plugin for Fileupload, full documentation here: http://www.jasny.net/bootstrap/javascript/#fileinput -->
      <script src="../../assets/js/plugins/jasny-bootstrap.min.js"></script>
      <!--  Full Calendar Plugin, full documentation here: https://github.com/fullcalendar/fullcalendar    -->
      <script src="../../assets/js/plugins/fullcalendar.min.js"></script>
      <!-- Vector Map plugin, full documentation here: http://jvectormap.com/documentation/ -->
      <script src="../../assets/js/plugins/jquery-jvectormap.js"></script>
      <!--  Plugin for the Sliders, full documentation here: http://refreshless.com/nouislider/ -->
      <script src="../../assets/js/plugins/nouislider.min.js"></script>
      <!-- Include a polyfill for ES6 Promises (optional) for IE11, UC Browser and Android browser support SweetAlert -->
      <script src="https://cdnjs.cloudflare.com/ajax/libs/core-js/2.4.1/core.js"></script>
      <!-- Library for adding dinamically elements -->
      <script src="../../assets/js/plugins/arrive.min.js"></script>
      <!--  Google Maps Plugin    -->
      <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
      <!-- Chartist JS -->
      <script src="../../assets/js/plugins/chartist.min.js"></script>
      <!--  Notifications Plugin    -->
      <script src="../../assets/js/plugins/bootstrap-notify.js"></script>
      <!-- Control Center for Material Dashboard: parallax effects, scripts for the example pages etc -->
      <script src="../../assets/js/material-dashboard.js?v=2.1.2" type="text/javascript"></script>
      <!-- Material Dashboard DEMO methods, don't include it in your project! -->
      <script src="../../assets/demo/demo.js"></script>
      <script>
        $(document).ready(function() {
          $().ready(function() {
            $sidebar = $('.sidebar');

            $sidebar_img_container = $sidebar.find('.sidebar-background');

            $full_page = $('.full-page');

            $sidebar_responsive = $('body > .navbar-collapse');

            window_width = $(window).width();

            fixed_plugin_open = $('.sidebar .sidebar-wrapper .nav li.active a p').html();

            if (window_width > 767 && fixed_plugin_open == 'Dashboard') {
              if ($('.fixed-plugin .dropdown').hasClass('show-dropdown')) {
                $('.fixed-plugin .dropdown').addClass('open');
              }

            }

            $('.fixed-plugin a').click(function(event) {
              // Alex if we click on switch, stop propagation of the event, so the dropdown will not be hide, otherwise we set the  section active
              if ($(this).hasClass('switch-trigger')) {
                if (event.stopPropagation) {
                  event.stopPropagation();
                } else if (window.event) {
                  window.event.cancelBubble = true;
                }
              }
            });

            $('.fixed-plugin .active-color span').click(function() {
              $full_page_background = $('.full-page-background');

              $(this).siblings().removeClass('active');
              $(this).addClass('active');

              var new_color = $(this).data('color');

              if ($sidebar.length != 0) {
                $sidebar.attr('data-color', new_color);
              }

              if ($full_page.length != 0) {
                $full_page.attr('filter-color', new_color);
              }

              if ($sidebar_responsive.length != 0) {
                $sidebar_responsive.attr('data-color', new_color);
              }
            });

            $('.fixed-plugin .background-color .badge').click(function() {
              $(this).siblings().removeClass('active');
              $(this).addClass('active');

              var new_color = $(this).data('background-color');

              if ($sidebar.length != 0) {
                $sidebar.attr('data-background-color', new_color);
              }
            });

            $('.fixed-plugin .img-holder').click(function() {
              $full_page_background = $('.full-page-background');

              $(this).parent('li').siblings().removeClass('active');
              $(this).parent('li').addClass('active');


              var new_image = $(this).find("img").attr('src');

              if ($sidebar_img_container.length != 0 && $('.switch-sidebar-image input:checked').length != 0) {
                $sidebar_img_container.fadeOut('fast', function() {
                  $sidebar_img_container.css('background-image', 'url("' + new_image + '")');
                  $sidebar_img_container.fadeIn('fast');
                });
              }

              if ($full_page_background.length != 0 && $('.switch-sidebar-image input:checked').length != 0) {
                var new_image_full_page = $('.fixed-plugin li.active .img-holder').find('img').data('src');

                $full_page_background.fadeOut('fast', function() {
                  $full_page_background.css('background-image', 'url("' + new_image_full_page + '")');
                  $full_page_background.fadeIn('fast');
                });
              }

              if ($('.switch-sidebar-image input:checked').length == 0) {
                var new_image = $('.fixed-plugin li.active .img-holder').find("img").attr('src');
                var new_image_full_page = $('.fixed-plugin li.active .img-holder').find('img').data('src');

                $sidebar_img_container.css('background-image', 'url("' + new_image + '")');
                $full_page_background.css('background-image', 'url("' + new_image_full_page + '")');
              }

              if ($sidebar_responsive.length != 0) {
                $sidebar_responsive.css('background-image', 'url("' + new_image + '")');
              }
            });

            $('.switch-sidebar-image input').change(function() {
              $full_page_background = $('.full-page-background');

              $input = $(this);

              if ($input.is(':checked')) {
                if ($sidebar_img_container.length != 0) {
                  $sidebar_img_container.fadeIn('fast');
                  $sidebar.attr('data-image', '#');
                }

                if ($full_page_background.length != 0) {
                  $full_page_background.fadeIn('fast');
                  $full_page.attr('data-image', '#');
                }

                background_image = true;
              } else {
                if ($sidebar_img_container.length != 0) {
                  $sidebar.removeAttr('data-image');
                  $sidebar_img_container.fadeOut('fast');
                }

                if ($full_page_background.length != 0) {
                  $full_page.removeAttr('data-image', '#');
                  $full_page_background.fadeOut('fast');
                }

                background_image = false;
              }
            });

            $('.switch-sidebar-mini input').change(function() {
              $body = $('body');

              $input = $(this);

              if (md.misc.sidebar_mini_active == true) {
                $('body').removeClass('sidebar-mini');
                md.misc.sidebar_mini_active = false;

                $('.sidebar .sidebar-wrapper, .main-panel').perfectScrollbar();

              } else {

                $('.sidebar .sidebar-wrapper, .main-panel').perfectScrollbar('destroy');

                setTimeout(function() {
                  $('body').addClass('sidebar-mini');

                  md.misc.sidebar_mini_active = true;
                }, 300);
              }

              // we simulate the window Resize so the charts will get updated in realtime.
              var simulateWindowResize = setInterval(function() {
                window.dispatchEvent(new Event('resize'));
              }, 180);

              // we stop the simulation of Window Resize after the animations are completed
              setTimeout(function() {
                clearInterval(simulateWindowResize);
              }, 1000);

            });
          });
        });
      </script>
      <script>
        $(document).ready(function() {
          // Initialise the wizard
          demo.initMaterialWizard();
          setTimeout(function() {
            $('.card.card-wizard').addClass('active');
          }, 600);
        });
      </script>
    </body>


</html>
